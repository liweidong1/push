//
//  AppDelegate.m
//  day02_PushService(推送符)
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 tarena. All rights reserved.
//
#warning 推送分为本地推送和远程推送
/*1本地推送:一般来制作闹钟,行程安排提醒,区域变化提醒
2远程推送服务器人员给客户端人员发送消息
 2.1必须到苹果开发者网站去申请    需要viss master (万事达,八达通)
 2.2需要到此网站搜索通过应用的唯一标识(bundle id),向苹果公司申请推送服务
 2.3还要同时申请一个推送证书给服务器人员
 2.4用户运行起来一个应用之后,会在协议中返回用户设备的唯一标识,,称为deviceToken
 2.5通过服务器人员给你的网络接口,吧deviceToken传递给服务器
 2.6服务器人员开始推送
   声音提示    文字提示  icon的标记提示
 */
#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate
#pragma mark - 远程推送服务协议
-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    
}
//启动后立即触发,,返回的是当前设备在苹果服务器上的唯一标识
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    
}
-(void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    
}



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
#warning 推送服务需要获取用户的许可才可以,需要在程序启东时获取用户的许可,ios8之前和之后获取许可的代码不同
    NSInteger version =[UIDevice currentDevice].systemVersion.floatValue;
    if (version < 8.0) {
        [application registerForRemoteNotificationTypes:UIRemoteNotificationTypeSound |
                                                        UIRemoteNotificationTypeAlert |
                                                        UIRemoteNotificationTypeBadge];
    }else { //  >=8.0
        UIUserNotificationSettings * settings = [UIUserNotificationSettings settingsForTypes:UIRemoteNotificationTypeSound| UIRemoteNotificationTypeAlert |
                                                                                 UIRemoteNotificationTypeBadge categories:nil];
        [application registerUserNotificationSettings:settings];
        //[application registerUserNotificationSettings:settings];
        
    }
    //1创建本地通知
    UILocalNotification * localNoti =[UILocalNotification new];
    //设置提示内容
    localNoti.alertBody = @"alertBody";
    //设置操作提示
    localNoti.alertAction = @"解锁";
    //设置推送的提示音,MP3格式,小于30秒
    localNoti.soundName = @"lingsheng.mp3";
    //设置图标上的数字
    localNoti.applicationIconBadgeNumber = 9;
    
    //安排当前时间10秒钟以后触发此操作
    localNoti.fireDate = [[NSDate date]dateByAddingTimeInterval:10];
    //安排通知操作
    [application scheduleLocalNotification:localNoti];
    //运行--->按cmd+L 锁频,,等10秒钟,打开电脑声音
    
    return YES;
}
#warning 下方协议方法会在推送消息被点击(桌面从屏幕上方弹出消息)(锁屏)右滑打开,当前消息就在前台时触发
-(void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    NSLog(@"notification %@",notification);
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}
//当应用程序被点击显示在前台,把图片上的数字去掉
- (void)applicationWillEnterForeground:(UIApplication *)application {
    application.applicationIconBadgeNumber = 0;
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
