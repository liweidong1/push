//
//  AppDelegate.h
//  异或加密
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 cheny. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

